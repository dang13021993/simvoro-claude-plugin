# SimVoro — Claude Directory plugin bundle source

This repository is intended for public Claude Directory submission as a **Plugin bundle**. It includes only reusable skills; it DOES NOT expose a remote MCP connector or claim live customer account access.

## Skills
- `start-here`: traveller needs and verification of public prices
- `travel-esim-selector`: compare published data plans and transparent value metrics
- `esim-phone-check`: verify device and regional model caveats
- `simvoro-sms-prices`: read-only public service/price discovery; NO OTP retrieval or number rental

## References
- Official site: https://simvoro.com
- eSIM: https://simvoro.com/esim
- SMS catalogue: https://simvoro.com/sms
- Help: https://simvoro.com/help
- Privacy: https://simvoro.com/privacy
- Terms: https://simvoro.com/terms
- Refunds: https://simvoro.com/refund-policy

## Disclosure

The contents are a public-submission **candidate**, not an approved Directory listing. They make no direct API calls and cannot place orders or read private user data. The site operator must resolve unfinished legal policy text before submission and independently satisfy Anthropic's verification, testing, and publication requirements.
